// If the format of this file changes, so it doesn't simply export a VERSION constant,
// this will break .github/workflows/version-check.yml.
export const VERSION = "0.6.2";