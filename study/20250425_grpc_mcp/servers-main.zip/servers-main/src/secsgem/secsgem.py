from typing import Any
import grpc
import asyncio
from mcp.server.fastmcp import FastMCP
from datetime import datetime
from protos import semi_gem_pb2, semi_gem_pb2_grpc

# SECSGEM MCP 서버 초기화
mcp = FastMCP("secsgem")

# gRPC 클라이언트 설정을 위한 상수
GRPC_SERVER_ADDRESS = "127.0.0.1:50051"  # gRPC 서버 주소

# gRPC 연결을 위한 설정
class GRPCClient:
    def __init__(self, address: str):
        """gRPC 클라이언트 초기화"""
        self.address = address
        self.channel = None
        self.stub = None
    
    async def connect(self):
        """gRPC 서버에 연결"""
        try:
            self.channel = grpc.aio.insecure_channel(self.address)
            self.stub = semi_gem_pb2_grpc.SEMI_GEM_ServiceStub(self.channel)
            print(f"Successfully connected to gRPC server at {self.address}")
        except Exception as e:
            print(f"Failed to connect to gRPC server: {str(e)}")
    
    async def close(self):
        """gRPC 연결 종료"""
        if self.channel:
            await self.channel.close()
            print("gRPC connection closed")
    
    async def get_equipment_status(self) -> str:
        """gRPC를 통해 장비의 상태 데이터 요청 (S1F3/S1F4)"""
        try:
            request = semi_gem_pb2.S1F3(
                svid_list=[1]  # VID 1번 요청
            )
            response = await self.stub.SelectedEquipmentStatusRequest(request)
            return f"Equipment Status: {response.sv_list[0]}"
        except Exception as e:
            return f"Error getting equipment status: {str(e)}"

    async def get_date_time(self) -> str:
        """gRPC를 통해 장비의 날짜와 시간 요청 (S2F17/S2F18)"""
        try:
            request = semi_gem_pb2.S2F17()
            response = await self.stub.DateandTimeRequest(request)
            return f"Equipment Time: {response.TIME}"
        except Exception as e:
            return f"Error getting date/time: {str(e)}"
        
    async def send_terminal_message(self, msg : str) -> str:
        """gRPC를 통해 장비에 터미널 메시지 전달 (S10F5/S10F6)"""
        try:
            # S10F5 메시지 생성
            request = semi_gem_pb2.S10F5(
                TID=1,  # Terminal ID를 1로 설정
                TEXT_LIST=[msg]  # 메시지를 리스트로 전달
            )
            # 메시지 전송 및 응답 수신
            response = await self.stub.TerminalDisplayMultiBlock(request)
            
            # 응답 코드에 따른 결과 반환
            if response.ACKC10 == 0:  # 0은 일반적으로 성공을 의미
                return "Message sent successfully"
            else:
                return f"Message send failed with ACKC10: {response.ACKC10}"
        except Exception as e:
            return f"Error sending terminal message: {str(e)}"

# gRPC 클라이언트 인스턴스 생성
grpc_client = GRPCClient(GRPC_SERVER_ADDRESS)

@mcp.tool()
async def get_equipment_time() -> str:
    """장비의 현재 시간을 가져옵니다.
    
    반환값:
        str: ISO 8601 형식의 시간 문자열 (YYYY-MM-DDThh:mm:ss.sss)
    """
    # gRPC 클라이언트가 연결되어 있지 않으면 연결
    if grpc_client.stub is None:
        await grpc_client.connect()
    
    # 장비 시간 요청
    return await grpc_client.get_date_time()

@mcp.tool()
async def send_terminal_msg(msg : str) -> str:
    """장비에 터미널 메시지를 전달 합니다.
    
    매개변수:
        msg (str): 장비에 전송할 메시지
    
    반환값:
        str: 메시지 전송 결과
    """
    # gRPC 클라이언트가 연결되어 있지 않으면 연결
    if grpc_client.stub is None:
        await grpc_client.connect()
    
    # 터미널 메시지 전송
    return await grpc_client.send_terminal_message(msg)

@mcp.tool()
async def get_equipment_status() -> str:
    """장비의 현재 상태를 가져옵니다.
    
    반환값:
        str: 장비의 현재 상태 문자열 ("STOP", "RUN", "PAUSE")
    """
    # gRPC 클라이언트가 연결되어 있지 않으면 연결
    if grpc_client.stub is None:
        await grpc_client.connect()
    
    # 장비 시간 요청
    return await grpc_client.get_equipment_status()

if __name__ == "__main__":
    print("Starting SECSGEM MCP server...")
    # 서버 초기화 및 실행
    mcp.run(transport='stdio')