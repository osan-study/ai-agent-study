import asyncio
import grpc
from protos import semi_gem_pb2, semi_gem_pb2_grpc

async def test_grpc_connection():
    try:
        # gRPC 서버에 연결
        channel = grpc.aio.insecure_channel('127.0.0.1:50051')
        stub = semi_gem_pb2_grpc.SEMI_GEM_ServiceStub(channel)
        
        print("Connecting to gRPC server...")
        
        # S2F17 요청 생성 및 전송
        request = semi_gem_pb2.S2F17()
        print("Sending S2F17 request...")
        
        response = await stub.DateandTimeRequest(request)
        print(f"Received response: {response.TIME}")
        
        await channel.close()
        
    except Exception as e:
        print(f"Error occurred: {str(e)}")

if __name__ == "__main__":
    print("Starting gRPC test...")
    asyncio.run(test_grpc_connection()) 