from mcp_server_time import main

main()
